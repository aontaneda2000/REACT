/**************************/
/* Delegación de eventos */
/*************************/
/* ¡La delegación de eventos es verdaderamente fantástica! Es uno de los patrones más útiles entre los eventos DOM. */

// const addsButtons = Array.from(document.querySelectorAll('.btn-add'))

// addsButtons.forEach(btn => {
//   btn.addEventListener('click', (e) => {
//     console.log(btn.dataset.id)
//   })
// })

// => La idea es que si tenemos muchos elementos manejados de manera similar podemos, en lugar de asignar un manejador a cada uno de ellos, poner un único manejador a su ancestro común.

const section = document.getElementById('content')

section.addEventListener('click', (e) => {

  if (e.target.classList.contains('btn-add')) {
    console.log(e.target.dataset.id)
  }

})

const counterContainer = document.querySelector('.counters')

counterContainer.addEventListener('click', (e) => {
  if (e.target.dataset.counter !== undefined) {
    e.target.value++
  }
})

// Acordeon
document.addEventListener('click', (e) => {
  const id = e.target.dataset.toggleId
  if (!id) return
  const contenido = document.getElementById(id)
  contenido.hidden = !contenido.hidden
})

/* Beneficios:
  - Simplifica la inicialización y ahorra memoria: no hay necesidad de agregar muchos controladores.
  - Menos código: cuando agregamos o quitamos elementos, no hay necesidad de agregar y quitar controladores.
  - Modificaciones del DOM: podemos agregar y quitar elementos en masa con innerHTML y similares.

La delegación tiene sus limitaciones por supuesto:
  - Primero, el evento debe “propagarse”. Algunos eventos no lo hacen. Además manejadores de bajo nivel no deben usar event.stopPropagation().
  
  - Segundo, la delegación puede agregar carga a la CPU, porque el controlador a nivel de contenedor reacciona a eventos en cualquier lugar del mismo, no importa si nos interesan o no. Pero usualmente la carga es imperceptible y no la tomamos en cuenta. */