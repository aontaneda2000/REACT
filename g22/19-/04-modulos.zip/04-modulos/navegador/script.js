function foo() {
  return 'hola como estan'
}

function bar() {
  return 'Hola soy otra función'
}

const PI = Math.PI

// export {
//   foo,
//   bar
// }

export {
  foo,
  bar
}
export default PI