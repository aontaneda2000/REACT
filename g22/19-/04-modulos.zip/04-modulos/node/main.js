import { foo as videoModal } from './script.js'

const settings = {
  videoID: 'fk-EC1KcHx0'
}

videoModal(settings)